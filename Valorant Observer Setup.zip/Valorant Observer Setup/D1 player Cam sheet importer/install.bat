npm install
pause